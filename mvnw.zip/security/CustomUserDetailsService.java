package com.mugi.skillsoft.security;

import com.mugi.skillsoft.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Let people login with either username or email
//        UserRepository userRepository = ITaxApplication.context.getBean(UserRepository.class);
        User user = new User(email);

        return UserPrincipal.create(user, true);
    }

    // This method is used by JWTAuthenticationFilter
    @Transactional
    public UserDetails loadUserById(String id) {
//        UserRepository userRepository = ITaxApplication.context.getBean(UserRepository.class);
        System.out.println("id===" + id);
        User user = new User(id);
        return UserPrincipal.create(user, true);
    }
}
