/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.security;

/**
 *
 * @author @saqlever
 */
import com.mugi.skillsoft.entity.User;
import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

public class UserAuthentication implements Authentication {

    /**
     *
     *
     *
     */
    private static final long serialVersionUID = 5111009914138985412L;

    private final User user;

    private final boolean authenticated;

    public UserAuthentication(User user, boolean authenticated) {

        this.user = user;

        this.authenticated = authenticated;

    }

    @Override

    public String getName() {

        // TODO Auto-generated method stub
        return user.getFirstName();

    }

    @Override

    public List<GrantedAuthority> getAuthorities() {

        return user.getAuthorities();

    }

    @Override

    public Object getCredentials() {

        return user.getEmail();

    }

    @Override

    public User getDetails() {

        // TODO Auto-generated method stub
        return user;

    }

    @Override

    public Object getPrincipal() {

        // TODO Auto-generated method stub
        return user.getEmail();

    }

    @Override

    public boolean isAuthenticated() {

        // TODO Auto-generated method stub
        return authenticated;

    }

    @Override

    public void setAuthenticated(boolean isAuthenticated)
            throws IllegalArgumentException {

        // TODO Auto-generated method stub
    }

}
