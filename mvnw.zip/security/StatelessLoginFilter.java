package com.mugi.skillsoft.security;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.mugi.skillsoft.entity.JwtAuthenticationResponse;
import com.mugi.skillsoft.entity.LoginRequest;
import com.mugi.skillsoft.entity.User;
import com.mugi.skillsoft.services.UserService;
import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

public class StatelessLoginFilter extends AbstractAuthenticationProcessingFilter {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    CustomUserDetailsService userDetailsService;
    JwtTokenProvider tokenProvider;
    UserService usersService;

    //private UserService userService;
    protected StatelessLoginFilter(UserService usersService, JwtTokenProvider tokenProvider, String urlMapping, CustomUserDetailsService userDetailsService) {

        super(new AntPathRequestMatcher(urlMapping));

        this.userDetailsService = userDetailsService;
        this.tokenProvider = tokenProvider;
        this.usersService = usersService;

    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws AuthenticationException, IOException, ServletException {

        LoginRequest loginRequest = null;
        try {
            BufferedReader reader = request.getReader();
            Gson gson = new Gson();
            loginRequest = gson.fromJson(reader, LoginRequest.class);
            System.out.println("attemptAuthentication ==" + loginRequest.toString());
            if (loginRequest == null) {
                throw new BadCredentialsException("Credentials not provided.");
            }
            if (loginRequest.getUsername().length() <= 0 || loginRequest.getUsername() == null) {
                throw new BadCredentialsException("Username not found.");
            }

            if (loginRequest.getPassword().length() <= 0 || loginRequest.getPassword() == null) {
                throw new BadCredentialsException("Wrong password.");
            }

        } catch (JsonIOException | JsonSyntaxException | IOException | BadCredentialsException e) {
            System.out.println("attemptAuthe get request from body");
            throw new BadCredentialsException("Wrong password.");
        }

        final UsernamePasswordAuthenticationToken loginToken = new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword());
        return loginToken;

    }

    @Override

    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
            Authentication authentication) throws IOException, ServletException {

        // Lookup the complete user object from the database/ldap and create an
        // authentication for it
        String ipAddress = request.getHeader("X-FORWARDED-FOR");

        try {

            System.out.println("USING ACTIVE DIRECTORY DOMAIN: ");

// ObjectMapper mapper = new ObjectMapper();
// System.out.println("*************** AUTHENTICATION ********************\n"+mapper.writeValueAsString(authentication));
            String username = authentication.getName();
            String password = authentication.getCredentials().toString();

//                                            String username = ((User)authentication.getPrincipal()).getUsername();
//                                            username = username.contains("@") == true ? StringUtils.split(username,"@")[0] : username;
            // username = !username.contains("@") ? username.concat("@kcb.co.ke") : username;
            LoginRequest lr = usersService.authenticateUser(username, password, ipAddress);
            log.info(lr.toString());
            if (lr.isSuccess()) {

                UserPrincipal userPrincipal = (UserPrincipal) userDetailsService.loadUserByUsername(username);
                UserAuthentication authenticatedUser = new UserAuthentication(userPrincipal.getUser(), userPrincipal.isAuthenticated());
// Add the custom token as Http header to the response
                String loginMode = "<I&M: LDAP DOMAIN>";
                if (authenticatedUser.isAuthenticated()) {
                    // The Auth Mechanism stores the Username the Principal.
                    // The username is stored in the Subject field of the Token

                    String token = tokenProvider.generateToken(lr.getUser());

                    response.addHeader("Access-Control-Expose-Headers", "Authorization");
                    response.addHeader("Access-Control-Allow-Headers", "Authorization, X-PINGOTHER, Origin, X-Requested-With, Content-Type, Accept, X-Custom-header");
                    response.addHeader("Authorization", "Bearer " + token);
                    User user = userPrincipal.getUser();
                    String json = new Gson().toJson(new JwtAuthenticationResponse(token, lr.getUser(), true));
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);
//UPDATE TOKEN DETAILS FOR THE USER

                } else {
                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Users not registered to Application.");

                }
            } else {
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Users not registered to Application.");
                throw new BadCredentialsException(lr.getMessage());
            }

        } catch (IOException | UsernameNotFoundException e) {
            System.out.println("UsernameNotFoundException successfulAuthentication Exception");
            logger.error(e);
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Users not registered to Application.");

        }

    }

    @Override

    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed)
            throws IOException, ServletException {

        System.out.println("protected void unsuccessfulAuthentication Exception");
        logger.error(failed);

        super.unsuccessfulAuthentication(request, response, failed);

    }

}
