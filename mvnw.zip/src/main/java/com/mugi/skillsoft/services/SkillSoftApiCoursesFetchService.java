/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mugi.skillsoft.entity.CoursesResponse;
import com.mugi.skillsoft.entity.SkillsoftCourse;
import com.mugi.skillsoft.repos.SkillsoftCoursesRepository;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.transaction.Transactional;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author @saqlever
 */
@Service
public class SkillSoftApiCoursesFetchService {

    private final org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass());
    Gson gson = new Gson();

    @Value("${skillsoft.token}")
    private String orgToken;
    @Value("${skillsoft.orgid}")
    private String orgId;
    @Value("${skillsoft.courses.url}")
    private String skillsoftcoursesurl;

    @Autowired
    SkillsoftCoursesRepository coursesRepository;

//    @Scheduled(fixedDelayString = "${coursesdelay.in.milliseconds}", initialDelay = 3000)
    private void initializeSchedulerFetchCoursesDataFromSkillSoftApis() {
        log.info("initialize Scheduler Fetch Courses Data From SkillSoft Apis Started @" + new Date());
        try {
            fetchAllCoursesFromSkillSoft();
        } catch (Exception ex) {
            Logger.getLogger(SkillSoftApiCoursesFetchService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void fetchAllCoursesFromSkillSoft() {
        try {
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.get(skillsoftcoursesurl.replaceAll("ORGID", orgId))
                    .header("Authorization", "Bearer " + orgToken)
                    .header("Cookie", "AWSALB=Z3C2fL2jTePNCBXViPTNBjwMn9wKAHjJhwxJnh0VlM7MCohMlS+lxhCn1eKK8tJdJ9JAAOc0BNL5bg1K6OLIC8SOtLowWglnOU9oz1w3ZEPPjIc9QFYt0tu98cxM; AWSALBCORS=Z3C2fL2jTePNCBXViPTNBjwMn9wKAHjJhwxJnh0VlM7MCohMlS+lxhCn1eKK8tJdJ9JAAOc0BNL5bg1K6OLIC8SOtLowWglnOU9oz1w3ZEPPjIc9QFYt0tu98cxM")
                    .asString();
            log.info("\n" + response.getBody());
            formatAndSaveCourseData(response.getBody());
        } catch (UnirestException ex) {
            Logger.getLogger(SkillSoftApiCoursesFetchService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Transactional
    private void formatAndSaveCourseData(String response) {
        try {
            List<CoursesResponse> skillsoftCourses = Arrays.asList(new GsonBuilder().create().fromJson(response, CoursesResponse[].class));
            saveCourseToDb(skillsoftCourses);
            log.info("formatAndSaveCourseData size is=" + skillsoftCourses.size());
        } catch (Exception ex) {
            Logger.getLogger(SkillSoftApiCoursesFetchService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void saveCourseToDb(List<CoursesResponse> coursesResponses) {
        coursesResponses.stream()
                .forEach(course -> {
                    if (course.getId().trim().length() > 0) {
                        SkillsoftCourse skillsoftCourse = buildSkillSoftCourse(course);
                        coursesRepository.save(skillsoftCourse);
                    }
                });
    }

    private SkillsoftCourse buildSkillSoftCourse(CoursesResponse softCourseResponse) {
        SkillsoftCourse skillsoftCourse = new SkillsoftCourse();

        skillsoftCourse.setCourseuuid(softCourseResponse.getId());
        skillsoftCourse.setAssetType(softCourseResponse.getContentType().getCategory());
        if (softCourseResponse.getLocalizedMetadata().size() > 0) {
            skillsoftCourse.setActivityName(softCourseResponse.getLocalizedMetadata().get(0).getTitle());
        }
        log.info("skillsoftCourse===\n" + skillsoftCourse.toString());
        return skillsoftCourse;
    }

}
