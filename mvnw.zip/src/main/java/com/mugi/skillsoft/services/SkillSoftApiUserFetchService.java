/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mugi.skillsoft.entity.SkillSoftUserResponse;
import com.mugi.skillsoft.entity.Skillsoftuser;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.transaction.Transactional;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.mugi.skillsoft.repos.SkillsoftLearnersRepository;

/**
 *
 * @author @saqlever
 */
@Service
public class SkillSoftApiUserFetchService {

    private final org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass());
    Gson gson = new Gson();

    @Value("${skillsoft.token}")
    private String orgToken;
    @Value("${skillsoft.orgid}")
    private String orgId;
    @Value("${skillsoft.users.url}")
    private String skillsoftusersurl;
    @Autowired
    SkillsoftLearnersRepository skillsoftusersRepository;

//    @Scheduled(fixedDelayString = "${usersdelay.in.milliseconds}", initialDelay = 3000)
    private void initializeSchedulerFetchUsersDataFromSkillSoftApis() {
        log.info("initialize Scheduler Fetch Users Data From Skill Soft Apis Started @" + new Date());
        try {
            fetchAllUsersFromSkillSoft();
        } catch (Exception ex) {
            Logger.getLogger(SkillSoftApiUserFetchService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void fetchAllUsersFromSkillSoft() {
        try {
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.get(skillsoftusersurl.replaceAll("ORGID", orgId))
                    .header("Authorization", "Bearer " + orgToken)
                    .header("Content-Type", "application/json")
                    .asString();

//  log.info("\n" + response.getBody());
            formatAndSaveUserData(response.getBody());
        } catch (UnirestException ex) {
            Logger.getLogger(SkillSoftApiUserFetchService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Transactional
    private void formatAndSaveUserData(String response) {
        try {
            List<SkillSoftUserResponse> skillsoftUsers = new ArrayList<>();
            skillsoftUsers = Arrays.asList(new GsonBuilder().create().fromJson(response, SkillSoftUserResponse[].class));
            saveUserToDb(skillsoftUsers);
            log.info("formatAndSaveUserData size is=" + skillsoftUsers.size());
        } catch (Exception ex) {
            Logger.getLogger(SkillSoftApiUserFetchService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void saveUserToDb(List<SkillSoftUserResponse> skillsoftUsers) {
        skillsoftUsers.stream()
                .forEach(softUserResponse -> {
                    if (softUserResponse.getId().trim().length() > 0) {
                        Skillsoftuser skillsoftuser = buildSkillSoftUser(softUserResponse);
                        skillsoftusersRepository.save(skillsoftuser);
                    }
                });
    }

    private Skillsoftuser buildSkillSoftUser(SkillSoftUserResponse softUserResponse) {
        Skillsoftuser skillsoftuser = new Skillsoftuser();

        skillsoftuser.setUserid(softUserResponse.getId());
        skillsoftuser.setEmail(softUserResponse.getEmail());
        skillsoftuser.setFirstName(softUserResponse.getFirstName());
        skillsoftuser.setLastName(softUserResponse.getLastName());
        skillsoftuser.setLoginName(softUserResponse.getLoginName());
        softUserResponse.getCustomAttributes().stream()
                .forEach(attr -> {
                    switch (attr.getName()) {
                        case "Branch/Sub Unit": {
                            skillsoftuser.setBranchSubUnit(attr.getValue());
                        }
                        break;
                        case "Country": {
                            skillsoftuser.setCountry(attr.getValue());
                        }
                        break;
                        case "Department": {
                            skillsoftuser.setDepartment(attr.getValue());
                        }
                        break;
                        case "Division": {
                            skillsoftuser.setDivision(attr.getValue());
                        }
                        break;
                        case "Head Office/Branch": {
                            skillsoftuser.setHeadOfficeBranch(attr.getValue());
                        }
                        break;
                        case "Job Title": {
                            skillsoftuser.setJobTitle(attr.getValue());
                        }
                        break;
                        case "Manager Email": {
                            skillsoftuser.setManagerEmail(attr.getValue());
                        }
                        break;
                        case "Manager Name": {
                            skillsoftuser.setManagerName(attr.getValue());
                        }
                        break;
                        case "Permanent and Pensionable": {
                            skillsoftuser.setPermanentPensionable(attr.getValue());
                        }
                        break;
                        case "PF. No.": {
                            skillsoftuser.setPFNo(attr.getValue());
                        }
                        break;
                        case "Region/Unit": {
                            skillsoftuser.setRegionUnit(attr.getValue());
                        }
                        break;
                        case "User Status": {
                            skillsoftuser.setUserStatus(attr.getValue());
                        }
                        break;
                    }
                });
        log.info("skillsoftuser===\n" + skillsoftuser.toString());
        return skillsoftuser;
    }

}
