/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.services;

import com.mugi.skillsoft.repos.SkillsoftActivityRepository;
import com.mugi.skillsoft.repos.SkillsoftCoursesRepository;
import com.mugi.skillsoft.repos.SkillsoftLearnersRepository;
import com.mugi.skillsoft.utils.RestResponse;
import com.mugi.skillsoft.utils.RestResponseObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 *
 * @author @SaQlever
 */
@Service
public class SkillSoftService {

    @Autowired
    SkillsoftActivityRepository activityRepository;
    @Autowired
    SkillsoftCoursesRepository coursesRepository;
    @Autowired
    SkillsoftLearnersRepository learnersRepository;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

//    public RestResponse listItem(Pageable pageable) {
//        RestResponseObject resp = new RestResponseObject();
//        resp.setMessage("Error listing Items  ");
//        resp.setRequestStatus(false);
//        resp.setPayload(null);
//
//        try {
//            resp.setPayload(itemsRepository.findAll(pageable));
//            resp.setRequestStatus(true);
//            resp.setMessage("Success");
//            return new RestResponse(resp, HttpStatus.OK);
//        } catch (Exception er) {
//            log.error(" ERROR:- " + er.getLocalizedMessage());
//            resp.setMessage("Error fetching Items  ");
//            resp.setRequestStatus(false);
//            return new RestResponse(resp, HttpStatus.BAD_REQUEST);
//        }
//    }
    public RestResponse listAllLearners(Pageable pageable) {
        RestResponseObject resp = new RestResponseObject();
        resp.setMessage("Error listing Items  ");
        resp.setRequestStatus(false);
        resp.setPayload(null);

        try {
            resp.setPayload(learnersRepository.findAll(pageable));
            resp.setRequestStatus(true);
            resp.setMessage("Success");
            return new RestResponse(resp, HttpStatus.OK);
        } catch (Exception er) {
            log.error(" ERROR:- " + er.getLocalizedMessage());
            resp.setMessage("Error fetching Items  ");
            resp.setRequestStatus(false);
            return new RestResponse(resp, HttpStatus.BAD_REQUEST);
        }
    }

    public RestResponse listAllLearningActivity(Pageable pageable) {
        RestResponseObject resp = new RestResponseObject();
        resp.setMessage("Error listing Items  ");
        resp.setRequestStatus(false);
        resp.setPayload(null);

        try {
            resp.setPayload(activityRepository.findAll(pageable));
            resp.setRequestStatus(true);
            resp.setMessage("Success");
            return new RestResponse(resp, HttpStatus.OK);
        } catch (Exception er) {
            log.error(" ERROR:- " + er.getLocalizedMessage());
            resp.setMessage("Error fetching Items  ");
            resp.setRequestStatus(false);
            return new RestResponse(resp, HttpStatus.BAD_REQUEST);
        }
    }

    public RestResponse listAllCourses(Pageable pageable) {
        RestResponseObject resp = new RestResponseObject();
        resp.setMessage("Error listing Items  ");
        resp.setRequestStatus(false);
        resp.setPayload(null);

        try {
            resp.setPayload(coursesRepository.findAll(pageable));
            resp.setRequestStatus(true);
            resp.setMessage("Success");
            return new RestResponse(resp, HttpStatus.OK);
        } catch (Exception er) {
            log.error(" ERROR:- " + er.getLocalizedMessage());
            resp.setMessage("Error fetching Items  ");
            resp.setRequestStatus(false);
            return new RestResponse(resp, HttpStatus.BAD_REQUEST);
        }
    }

}
