/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mugi.skillsoft.entity.LearnerActivityReportRequest;
import com.mugi.skillsoft.entity.LearningActivityResponse;
import com.mugi.skillsoft.entity.SkillsoftLearning;
import com.mugi.skillsoft.repos.SkillsoftActivityRepository;
import com.mugi.skillsoft.repos.SkillsoftCoursesRepository;
import com.mugi.skillsoft.repos.SkillsoftLearnersRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.transaction.Transactional;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author @saqlever
 */
@Service
public class SkillSoftLearningActivityService {

    private final org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass());
    Gson gson = new Gson();

    @Value("${skillsoft.token}")
    private String orgToken;
    @Value("${skillsoft.orgid}")
    private String orgId;
    @Value("${skillsoft.LearningActivityReportRequest.url}")
    private String learningactivityrequesturl;
    @Value("${skillsoft.LearningActivityData.url}")
    private String learningactivitydataurl;
    @Value("${skillsoft.timeframe}")
    private String skillsofttimeframe;
    @Autowired
    SkillsoftLearnersRepository skillsoftusersRepository;
    @Autowired
    SkillsoftCoursesRepository coursesRepository;
    @Autowired
    SkillsoftActivityRepository learningRepository;

//    @Scheduled(fixedDelayString = "${learningactivitydelay.in.milliseconds}", initialDelay = 3000)
    private void initializeSchedulerFetchLearningActivityDataFromSkillSoftApis() {
        log.info("initialize Scheduler Fetch Learning Activity Data From SkillSoft Apis Started @" + new Date());
        try {
            fetchLearningActivityData();
        } catch (Exception ex) {
            Logger.getLogger(SkillSoftLearningActivityService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Transactional
    private void fetchLearningActivityData() throws InterruptedException {
        try {
            LearnerActivityReportRequest reportRequest = getReportRequestId();
            Thread.sleep(5000);
            if (reportRequest.getId() != null) {

                List<LearningActivityResponse> myList = new ArrayList<>();
                String response = getLearningActivityData(reportRequest);
                while (response.contains("IN_PROGRESS")) {
                    log.info("response.contains(IN_PROGRESS)=" + response.contains("IN_PROGRESS"));
                    Thread.sleep(20000);
                    response = getLearningActivityData(reportRequest);
                }
                formatAndSaveUserData(response);
                log.info("Percipio data logged successfully!!!");
                log.info("\n               Completed " + new Date() + "\n               *********************************\n\n\n\n");
            } else {
                log.info("Cannot get request id to fetch data");

            }
        } catch (UnirestException ex) {
            Logger.getLogger(SkillSoftLearningActivityService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private String getLearningActivityData(LearnerActivityReportRequest reportRequest) throws UnirestException {

        try {
            RequestConfig globalConfig = RequestConfig.custom()
                    .setCookieSpec(CookieSpecs.IGNORE_COOKIES).build();
            HttpClient httpclient = HttpClients.custom().setDefaultRequestConfig(globalConfig).build();
            Unirest.setHttpClient(httpclient);

            HttpResponse<String> response = Unirest.get(learningactivitydataurl.replaceAll("ORGID", orgId) + "" + reportRequest.getId())
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + orgToken)
                    .asString();
            log.info("responseBody =\n" + response.getBody());
            return response.getBody();
//            myList.stream().forEach(tData -> log.info(tData.toString()));
        } catch (Exception ex) {
            log.error("getLearningActivityData DuplicateKeyException \n." + ex);
            return "";
        }

    }

    private LearnerActivityReportRequest getReportRequestId() {
        LearnerActivityReportRequest reportRequest;
        try {

//            Unirest.setTimeouts(0, 0);
            RequestConfig globalConfig = RequestConfig.custom()
                    .setCookieSpec(CookieSpecs.IGNORE_COOKIES).build();
            HttpClient httpclient = HttpClients.custom().setDefaultRequestConfig(globalConfig).build();
            Unirest.setHttpClient(httpclient);
            HttpResponse<String> response = Unirest.post(learningactivityrequesturl.replaceAll("ORGID", orgId))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + orgToken)
                    .body("{\r\n\"timeFrame\": \"" + skillsofttimeframe + "\",\r\n\"sort\": {\r\n\"field\": \"lastAccessDate\",\r\n\"order\": \"desc\"\r\n},\r\n\"status\": \"COMPLETED\",\r\n\"isFileRequiredInSftp\": false,\r\n\"formatType\": \"JSON\"\r\n}")
                    .asString();
            reportRequest = gson.fromJson(response.getBody(), LearnerActivityReportRequest.class);;

            log.info("responseBody ==" + reportRequest.toString());
        } catch (UnirestException ex) {
            reportRequest = new LearnerActivityReportRequest();
            log.info("getLearningActivityRequestId Error \n." + ex);
        }
        return reportRequest;
    }

    @Transactional
    private void formatAndSaveUserData(String response) {
        try {
            List<LearningActivityResponse> activityResponses = new ArrayList<>();
            activityResponses = Arrays.asList(new GsonBuilder().create().fromJson(response, LearningActivityResponse[].class));
            saveUserToDb(activityResponses);
            log.info("formatAndSaveUserData size is=" + activityResponses.size());
        } catch (Exception ex) {
            Logger.getLogger(SkillSoftLearningActivityService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void saveUserToDb(List<LearningActivityResponse> responses) {
        responses.stream()
                .forEach(resp -> {
                    if (resp.getUserId().trim().length() > 0) {
                        SkillsoftLearning learning = buildLearningActivity(resp);
                        learningRepository.save(learning);
                    }
                });
    }

    private SkillsoftLearning buildLearningActivity(LearningActivityResponse activityResponse) {
        /**
         * private Long learnId; private String userId; private String
         * contentUuid; private String activityName; private String
         * completionStatus; private String completedDate; private String
         * StartDate; private String score;
         */
        SkillsoftLearning learning = new SkillsoftLearning();
        learning.setUserId(activityResponse.getUserId());
        learning.setContentUuid(activityResponse.getContentUuid());
        learning.setActivityName(activityResponse.getContentTitle());
        learning.setCompletionStatus(activityResponse.getStatus());
        learning.setCompletedDate(activityResponse.getCompletedDate().split("T")[0]);
        learning.setStartDate(activityResponse.getFirstAccess().split("T")[0]);
        learning.setScore(activityResponse.getHighScore());

        log.info("skillsoftCourse===\n" + learning.toString());
        return learning;
    }

}
