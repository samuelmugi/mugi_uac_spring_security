package com.mugi.skillsoft.utils;

public class RestResponseObject {

    public String message;
    private Object payload;
    private boolean requestStatus;
    private int quantity;

    public RestResponseObject() {
    }

    public RestResponseObject(boolean requestStatus, String message) {
        this.message = message;
        this.requestStatus = requestStatus;
    }

    public RestResponseObject(String message, Object payload, boolean requestStatus) {
        this.message = message;
        this.payload = payload;
        this.requestStatus = requestStatus;
    }
    
    

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getPayload() {
        return payload;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }

    public boolean isRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(boolean requestStatus) {
        this.requestStatus = requestStatus;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}
