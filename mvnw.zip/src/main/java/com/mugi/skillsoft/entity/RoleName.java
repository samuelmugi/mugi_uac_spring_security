package com.mugi.skillsoft.entity;

public enum RoleName {

	ROLE_USER, ROLE_ADMIN
}
