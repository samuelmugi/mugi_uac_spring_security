/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author saqlever
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@Table(name = "skillsoftusers", catalog = "skillsoft", schema = "public")
@XmlRootElement

public class Skillsoftuser implements Serializable {

    @Id
    @Basic(optional = false)
    @Column(name = "userid", nullable = false)
    private String userid;
    @Column(name = "email")
    private String email;
    @Column(name = "firstName")
    private String firstName;
    @Column(name = "lastName")
    private String lastName;
    @Column(name = "loginName")
    private String loginName;
    @Column(name = "branchSubUnit")
    private String branchSubUnit;
    @Column(name = "Country")
    private String country;
    @Column(name = "Department")
    private String department;
    @Column(name = "Division")
    private String division;
    @Column(name = "JobTitle")
    private String jobTitle;
    @Column(name = "ManagerEmail")
    private String managerEmail;
    @Column(name = "ManagerName")
    private String managerName;
    @Column(name = "PFNo")
    private String pFNo;
    @Column(name = "RegionUnit")
    private String regionUnit;
    @Column(name = "HeadOfficeBranch")
    private String headOfficeBranch;
    @Column(name = "PermanentPensionable")
    private String permanentPensionable;
    @Column(name = "UserStatus")
    private String userStatus;

}
