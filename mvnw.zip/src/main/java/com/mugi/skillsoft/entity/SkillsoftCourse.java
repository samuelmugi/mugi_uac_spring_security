/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author saqlever
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@Table(name = "SkillsoftCourses", catalog = "skillsoft", schema = "public")
@XmlRootElement

public class SkillsoftCourse implements Serializable {

    @Id
    @Basic(optional = false)
    private String courseuuid;
    private String assetType;
    private String activityName;

}
