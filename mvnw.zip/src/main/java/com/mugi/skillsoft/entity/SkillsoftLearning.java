/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author saqlever
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@Table(name = "SkillsoftLearnings", catalog = "skillsoft", schema = "public")
@XmlRootElement

public class SkillsoftLearning implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long learnId;
    private String userId;
    private String contentUuid;
    private String activityName;
    private String completionStatus;
    private String completedDate;
    private String StartDate;
    private String score;

}
