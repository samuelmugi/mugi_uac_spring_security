package com.mugi.skillsoft.repos;

import com.mugi.skillsoft.entity.User;
import java.math.BigDecimal;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    public Optional<User> findByUserId(BigDecimal userId);

    Optional<User> findByEmail(String email);

    Boolean existsByEmail(String email);
}
