/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mugi.skillsoft.controller;

import com.mugi.skillsoft.services.SkillSoftService;
import com.mugi.skillsoft.utils.RestResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author @SaQlever
 */
@RestController
@RequestMapping(value = "/Api")
@Api(value = "Skill Soft Access CRUD API", description = "Skill Soft Access CRUD API")
public class SkillSoftController {

    @Autowired
    SkillSoftService skillSoftService;

    /*-------------------------- List all   API ---------------------*/
    @GetMapping(value = "/listAllCourses", produces = "application/json")
    @ApiOperation(value = "Get a  list of all   Courses", notes = "The json list of Courses")
    public RestResponse listAllCourses(Pageable pageable) {
        return skillSoftService.listAllCourses(pageable);
    }

    /*-------------------------- List all   API ---------------------*/
    @GetMapping(value = "/listAllLearningActivity", produces = "application/json")
    @ApiOperation(value = "Get a  list of all   Learning Activity", notes = "The json list of Learning Activity")
    public RestResponse listAllLearningActivity(Pageable pageable) {
        return skillSoftService.listAllLearningActivity(pageable);
    }

    /*-------------------------- List all   API ---------------------*/
    @GetMapping(value = "/listAllLearners", produces = "application/json")
    @ApiOperation(value = "Get a  list of all   Users", notes = "The json list of Users")
    public RestResponse listAllLearners(Pageable pageable) {
        return skillSoftService.listAllLearners(pageable);
    }

}
